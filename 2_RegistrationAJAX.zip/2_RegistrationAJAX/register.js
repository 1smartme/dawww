document.getElementById("regForm").addEventListener("submit", function (e) {
  e.preventDefault();

  const user = {
    name: document.getElementById("name").value,
    email: document.getElementById("email").value,
    password: document.getElementById("password").value,
    yearOfStudy: document.getElementById("yearOfStudy").value,
    course: document.getElementById("course").value
  };

  let users = JSON.parse(localStorage.getItem("users")) || [];
  users.push(user);
  localStorage.setItem("users", JSON.stringify(users));

  alert("User registered!");
  window.location.href = "users.html"; // Redirect to user list
});
