# Practical 2
AJAX form with local storage.

## Viva Questions
1. What is AJAX?
2. How to store data in localStorage?
3. How to retrieve and display data on another page?